

# RuntimeBay

一个通过配置文件整合不同后端服务的轻量级框架。

## 项目简介

RuntimeBay 提供了一个统一的入口，通过配置文件将多个后端服务整合在一起，并提供 Web 管理界面进行路由配置、插件管理和监控。

## 目录结构

```
RuntimeBay/
├── DocApier/           # API 文档管理与 Web 管理界面
│   ├── Src/           # 前端源码 (HTML、CSS、JS)
│   └── index.js       # 服务入口
├── Mannager/          # 进程管理器
│   ├── Web/           # Web 界面
│   └── index.js       # 服务入口
├── Router/            # 反向代理路由
│   ├── ErrorPages/    # 错误页面
│   ├── index.js       # 路由核心
│   └── router.router  # 路由配置文件
├── ExamplePlugs/      # 插件示例
│   ├── index.js       # 插件代码
│   └── info.plug      # 插件信息配置
├── Plugs/             # 插件目录
└── index.js           # 主入口文件
```

## 核心组件

### Router（路由代理）

基于配置文件实现请求转发，支持：
- 路径前缀剥离 (`strip-prefix`)
- 负载均衡配置
- 错误页面自定义
- CORS 配置

### DocApier（管理面板）

功能完善的后台管理界面，包含：
- **仪表盘**: 服务状态统计
- **API 列表**: 查看和管理 API 接口
- **测试工具**: 接口测试功能
- **路由配置**: 可视化配置路由规则
- **插件管理**: 插件状态监控和日志
- **Robots 配置**: 爬虫协议管理

### 插件系统

支持通过 `info.plug` 配置文件开发自定义插件，每个插件可定义：
- 名称和版本
- 启动命令
- 端口配置

## 快速开始

### 安装依赖

```bash
npm install
```

### 启动服务

```bash
node index.js
```

或使用 Windows 批处理脚本：

```bash
start.bat
```

## 配置文件

### 路由配置 (`Router/router.router`)

```json
{
  "/api": {
    "target": "http://localhost:3000",
    "strip-prefix": "/api"
  }
}
```

### 插件配置 (`ExamplePlugs/info.plug`)

```json
{
  "name": "ExamplePlugs",
  "version": "1.0.0",
  "cmd": "node index.js",
  "port": 8080
}
```

## 开发说明

- **主入口** (`index.js`): 统一启动所有服务模块
- **Router**: 负责 HTTP 请求的反向代理
- **DocApier**: 提供 Web 管理界面和 API 文档
- **Mannager**: 管理子进程和日志

## 测试工具

项目中包含测试脚本：

- `benchmark.js`: HTTP 并发基准测试
- `test-stripprefix.js`: 前缀剥离功能测试

## 技术栈

- Node.js
- HTTP 服务器
- 文件系统操作
- 进程管理

## 许可证

详见项目根目录 `LICENSE` 文件。
