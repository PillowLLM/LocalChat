const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PUBLIC_ROOT = path.join(__dirname, 'Public');
const BOTDATA_ROOT = path.join(__dirname, 'botdata');
const BOTDATA_MOUNT = '/botdata/';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

function loadPort() {
  const infoPath = path.join(__dirname, 'info.plug');
  let port = 3002;
  try {
    const text = fs.readFileSync(infoPath, 'utf8');
    text.split('\n').forEach((line) => {
      const t = line.trim();
      if (t.toLowerCase().startsWith('port:')) {
        const n = parseInt(t.split(':')[1], 10);
        if (!Number.isNaN(n) && n > 0) port = n;
      }
    });
  } catch (_) {}
  return port;
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

function safeFilePath(root, rel) {
  const decoded = decodeURIComponent((rel || '').split('?')[0]);
  const normalized = path.normalize(decoded).replace(/^(\.\.(\/|\\|$))+/, '');
  const base = path.resolve(root);
  const target = path.resolve(base, normalized);
  const baseWithSep = base.endsWith(path.sep) ? base : base + path.sep;
  if (target !== base && !target.startsWith(baseWithSep)) return null;
  if (target === base) return null;
  return target;
}

function resolvePublicPath(pathname) {
  let rel = pathname.replace(/^\/+/, '') || '';

  if (rel === '' || rel.endsWith('/')) {
    const indexPath = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexPath && fs.existsSync(indexPath)) return indexPath;
  }

  let filePath = safeFilePath(PUBLIC_ROOT, rel);
  if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return filePath;
  }

  if (rel && !path.extname(rel)) {
    const asHtml = safeFilePath(PUBLIC_ROOT, rel + '.html');
    if (asHtml && fs.existsSync(asHtml) && fs.statSync(asHtml).isFile()) return asHtml;
    const indexInDir = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexInDir && fs.existsSync(indexInDir) && fs.statSync(indexInDir).isFile()) {
      return indexInDir;
    }
  }

  return null;
}

function resolveBotdataPath(pathname) {
  if (pathname === '/robots.txt') {
    return safeFilePath(BOTDATA_ROOT, 'robots.txt');
  }
  if (pathname.startsWith(BOTDATA_MOUNT)) {
    const rel = pathname.slice(BOTDATA_MOUNT.length);
    if (!rel || rel === '/') return null;
    return safeFilePath(BOTDATA_ROOT, rel);
  }
  return null;
}

const PORT = loadPort();

function sendFile(req, res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }
    const type = contentType(filePath);
    const headers = {
      'Content-Type': type,
      'Cache-Control': 'public, max-age=3600',
    };
    if (req.method === 'HEAD') {
      res.writeHead(200, { ...headers, 'Content-Length': st.size });
      res.end();
      return;
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    fs.createReadStream(filePath).pipe(res);
  });
}

http
  .createServer((req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    const pathname = path.posix.normalize((url.parse(req.url).pathname || '/').replace(/\\/g, '/'));
    if (pathname.startsWith('..')) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    let filePath = resolveBotdataPath(pathname);
    if (!filePath) {
      filePath = resolvePublicPath(pathname);
    }

    if (!filePath) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }

    sendFile(req, res, filePath);
  })
  .listen(PORT, () => {
    console.log(`[Stastic] Public: ${PUBLIC_ROOT}`);
    console.log(`[Stastic] robots 等 SEO 原始文件: ${BOTDATA_ROOT}`);
    console.log(`[Stastic] 端口 ${PORT}（/ → Public；仅 /robots.txt 与 /botdata/* 读 botdata）`);
  });
