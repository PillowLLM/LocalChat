const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PUBLIC_ROOT = path.join(__dirname, 'Public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
};

const mockData = [
  { id: 1, title: '欢迎使用 RuntimeBay', content: 'RuntimeBay 是一个强大的运行时环境管理平台', category: '文档' },
  { id: 2, title: '插件开发指南', content: '学习如何开发自定义插件扩展功能', category: '文档' },
  { id: 3, title: 'API 接口文档', content: '详细的 RESTful API 接口说明', category: '文档' },
  { id: 4, title: '配置文件说明', content: 'info.plug 配置文件参数详解', category: '文档' },
  { id: 5, title: 'Stastic 静态资源插件', content: '提供静态文件托管服务', category: '插件' },
  { id: 6, title: 'Search 搜索插件', content: '提供全文搜索功能', category: '插件' },
  { id: 7, title: '安装指南', content: '如何安装和配置 RuntimeBay', category: '文档' },
  { id: 8, title: '性能优化', content: '优化 RuntimeBay 运行性能的技巧', category: '文档' },
];

function loadPort() {
  const infoPath = path.join(__dirname, 'info.plug');
  let port = 3003;
  try {
    const text = fs.readFileSync(infoPath, 'utf8');
    text.split('\n').forEach((line) => {
      const t = line.trim();
      if (t.toLowerCase().startsWith('port:')) {
        const n = parseInt(t.split(':')[1], 10);
        if (!Number.isNaN(n) && n > 0) port = n;
      }
    });
  } catch (_) {}
  return port;
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

function safeFilePath(root, rel) {
  const decoded = decodeURIComponent((rel || '').split('?')[0]);
  const normalized = path.normalize(decoded).replace(/^(\.\.(\/|\\|$))+/, '');
  const base = path.resolve(root);
  const target = path.resolve(base, normalized);
  const baseWithSep = base.endsWith(path.sep) ? base : base + path.sep;
  if (target !== base && !target.startsWith(baseWithSep)) return null;
  if (target === base) return null;
  return target;
}

function resolvePublicPath(pathname) {
  let rel = pathname.replace(/^\/+/, '') || '';

  if (rel === '' || rel.endsWith('/')) {
    const indexPath = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexPath && fs.existsSync(indexPath)) return indexPath;
  }

  let filePath = safeFilePath(PUBLIC_ROOT, rel);
  if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return filePath;
  }

  if (rel && !path.extname(rel)) {
    const asHtml = safeFilePath(PUBLIC_ROOT, rel + '.html');
    if (asHtml && fs.existsSync(asHtml) && fs.statSync(asHtml).isFile()) return asHtml;
    const indexInDir = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexInDir && fs.existsSync(indexInDir) && fs.statSync(indexInDir).isFile()) {
      return indexInDir;
    }
  }

  return null;
}

function search(query) {
  if (!query || query.trim() === '') return [];
  
  const q = query.toLowerCase().trim();
  return mockData.filter(item => 
    item.title.toLowerCase().includes(q) ||
    item.content.toLowerCase().includes(q) ||
    item.category.toLowerCase().includes(q)
  );
}

function sendFile(req, res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }
    const type = contentType(filePath);
    const headers = {
      'Content-Type': type,
      'Cache-Control': 'public, max-age=3600',
    };
    if (req.method === 'HEAD') {
      res.writeHead(200, { ...headers, 'Content-Length': st.size });
      res.end();
      return;
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    fs.createReadStream(filePath).pipe(res);
  });
}

function parseBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      const parsed = JSON.parse(body);
      callback(null, parsed);
    } catch (err) {
      try {
        const params = new URLSearchParams(body);
        const obj = {};
        params.forEach((value, key) => {
          obj[key] = value;
        });
        callback(null, obj);
      } catch (e) {
        callback(e, null);
      }
    }
  });
}

const PORT = loadPort();

http
  .createServer((req, res) => {
    const pathname = path.posix.normalize((url.parse(req.url).pathname || '/').replace(/\\/g, '/'));
    const query = url.parse(req.url, true).query;

    if (pathname.startsWith('..')) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    if (pathname === '/api/search') {
      if (req.method === 'GET') {
        const results = search(query.q || '');
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: true, data: results, total: results.length }));
        return;
      }
      
      if (req.method === 'POST') {
        parseBody(req, (err, body) => {
          if (err) {
            res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ success: false, message: 'Invalid request body' }));
            return;
          }
          const results = search(body.q || '');
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: true, data: results, total: results.length }));
        });
        return;
      }
      
      res.writeHead(405, { Allow: 'GET, POST', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    if (pathname === '/api/suggest') {
      const suggestions = mockData.map(item => item.title).filter(title => 
        title.toLowerCase().includes((query.q || '').toLowerCase())
      ).slice(0, 5);
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ success: true, suggestions }));
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    let filePath = resolvePublicPath(pathname);

    if (!filePath) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }

    sendFile(req, res, filePath);
  })
  .listen(PORT, () => {
    console.log(`[Search] Public: ${PUBLIC_ROOT}`);
    console.log(`[Search] 端口 ${PORT}（/ → Public；/api/search 搜索接口）`);
  });
