const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PUBLIC_ROOT = path.join(__dirname, 'Public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
};

const mockUsers = [
  { username: 'admin', password: 'admin123', name: '管理员', role: 'admin' },
  { username: 'user', password: 'user123', name: '普通用户', role: 'user' },
];

let sessions = {};

function generateToken() {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function loadPort() {
  const infoPath = path.join(__dirname, 'info.plug');
  let port = 3004;
  try {
    const text = fs.readFileSync(infoPath, 'utf8');
    text.split('\n').forEach((line) => {
      const t = line.trim();
      if (t.toLowerCase().startsWith('port:')) {
        const n = parseInt(t.split(':')[1], 10);
        if (!Number.isNaN(n) && n > 0) port = n;
      }
    });
  } catch (_) {}
  return port;
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

function safeFilePath(root, rel) {
  const decoded = decodeURIComponent((rel || '').split('?')[0]);
  const normalized = path.normalize(decoded).replace(/^(\.\.(\/|\\|$))+/, '');
  const base = path.resolve(root);
  const target = path.resolve(base, normalized);
  const baseWithSep = base.endsWith(path.sep) ? base : base + path.sep;
  if (target !== base && !target.startsWith(baseWithSep)) return null;
  if (target === base) return null;
  return target;
}

function resolvePublicPath(pathname) {
  let rel = pathname.replace(/^\/+/, '') || '';

  if (rel === '' || rel.endsWith('/')) {
    const indexPath = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexPath && fs.existsSync(indexPath)) return indexPath;
  }

  let filePath = safeFilePath(PUBLIC_ROOT, rel);
  if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return filePath;
  }

  if (rel && !path.extname(rel)) {
    const asHtml = safeFilePath(PUBLIC_ROOT, rel + '.html');
    if (asHtml && fs.existsSync(asHtml) && fs.statSync(asHtml).isFile()) return asHtml;
    const indexInDir = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexInDir && fs.existsSync(indexInDir) && fs.statSync(indexInDir).isFile()) {
      return indexInDir;
    }
  }

  return null;
}

function sendFile(req, res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }
    const type = contentType(filePath);
    const headers = {
      'Content-Type': type,
      'Cache-Control': 'public, max-age=3600',
    };
    if (req.method === 'HEAD') {
      res.writeHead(200, { ...headers, 'Content-Length': st.size });
      res.end();
      return;
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    fs.createReadStream(filePath).pipe(res);
  });
}

function parseBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      const parsed = JSON.parse(body);
      callback(null, parsed);
    } catch (err) {
      try {
        const params = new URLSearchParams(body);
        const obj = {};
        params.forEach((value, key) => {
          obj[key] = value;
        });
        callback(null, obj);
      } catch (e) {
        callback(e, null);
      }
    }
  });
}

const PORT = loadPort();

http
  .createServer((req, res) => {
    const pathname = path.posix.normalize((url.parse(req.url).pathname || '/').replace(/\\/g, '/'));

    if (pathname.startsWith('..')) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    if (pathname === '/api/login') {
      if (req.method !== 'POST') {
        res.writeHead(405, { Allow: 'POST', 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
      }

      parseBody(req, (err, body) => {
        if (err) {
          res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: false, message: 'Invalid request body' }));
          return;
        }

        const { username, password } = body;
        const user = mockUsers.find(u => u.username === username && u.password === password);

        if (user) {
          const token = generateToken();
          sessions[token] = {
            user: { username: user.username, name: user.name, role: user.role },
            expires: Date.now() + 3600000
          };

          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({
            success: true,
            message: '登录成功',
            token,
            user: { username: user.username, name: user.name, role: user.role }
          }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: false, message: '用户名或密码错误' }));
        }
      });
      return;
    }

    if (pathname === '/api/logout') {
      if (req.method !== 'POST') {
        res.writeHead(405, { Allow: 'POST', 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Method Not Allowed');
        return;
      }

      parseBody(req, (err, body) => {
        if (err) {
          res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: false, message: 'Invalid request body' }));
          return;
        }

        const { token } = body;
        if (sessions[token]) {
          delete sessions[token];
        }

        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: true, message: '退出成功' }));
      });
      return;
    }

    if (pathname === '/api/verify') {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: false, message: '未授权' }));
        return;
      }

      const token = authHeader.slice(7);
      const session = sessions[token];

      if (session && session.expires > Date.now()) {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({
          success: true,
          user: session.user
        }));
      } else {
        if (session) delete sessions[token];
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: false, message: 'Token 已过期或无效' }));
      }
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    let filePath = resolvePublicPath(pathname);

    if (!filePath) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }

    sendFile(req, res, filePath);
  })
  .listen(PORT, () => {
    console.log(`[Login] Public: ${PUBLIC_ROOT}`);
    console.log(`[Login] 端口 ${PORT}（/ → Public；/api/login 登录接口）`);
  });
