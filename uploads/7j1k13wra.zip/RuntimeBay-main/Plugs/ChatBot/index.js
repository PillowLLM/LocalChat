const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PUBLIC_ROOT = path.join(__dirname, 'Public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
};

const responses = {
  greetings: [
    '您好！我是 RuntimeBay 的智能助手，很高兴为您服务！',
    '你好呀！有什么我可以帮助您的吗？',
    '您好！请问需要什么帮助？'
  ],
  thanks: [
    '不客气！很高兴能帮到您！',
    '不用谢，有问题随时找我！',
    '这是我应该做的！'
  ],
  help: [
    '我可以帮助您了解 RuntimeBay 的功能。您可以问我关于：\n- 插件开发\n- API 接口\n- 配置说明\n- 常见问题',
    '请问您需要哪方面的帮助？我可以解答关于 RuntimeBay 的各种问题。',
    '有什么问题尽管问，我会尽力解答！'
  ],
  plugin: [
    'RuntimeBay 支持插件扩展，您可以通过创建插件来扩展功能。每个插件需要包含 info.plug 配置文件和入口脚本。',
    '插件开发非常简单！您只需要创建一个包含 info.plug 和 index.js 的目录即可。',
    '插件系统允许您添加自定义功能，如搜索、认证、聊天机器人等。'
  ],
  api: [
    'RuntimeBay 提供 RESTful API 接口，支持 JSON 格式的数据交换。',
    'API 接口包括登录认证、搜索、聊天等功能，具体请参考文档。',
    '您可以通过 GET 或 POST 请求与 API 交互，返回格式为 JSON。'
  ],
  config: [
    'info.plug 是插件的配置文件，包含名称、版本、端口等信息。',
    '配置文件支持的字段：name、version、author、description、port、autostart。',
    '端口号用于插件启动时绑定服务，建议使用 3000 以上的端口。'
  ],
  about: [
    'RuntimeBay 是一个强大的运行时环境管理平台，支持插件化扩展。',
    'RuntimeBay 提供统一的插件管理和路由分发机制。',
    '我们致力于打造一个灵活、可扩展的运行时环境。'
  ]
};

function getResponse(message) {
  const msg = message.toLowerCase().trim();

  if (msg.includes('你好') || msg.includes('您好') || msg.includes('嗨') || msg.includes('hello')) {
    return responses.greetings[Math.floor(Math.random() * responses.greetings.length)];
  }

  if (msg.includes('谢谢') || msg.includes('感谢') || msg.includes('thank')) {
    return responses.thanks[Math.floor(Math.random() * responses.thanks.length)];
  }

  if (msg.includes('帮助') || msg.includes('help') || msg.includes('请问')) {
    return responses.help[Math.floor(Math.random() * responses.help.length)];
  }

  if (msg.includes('插件') || msg.includes('plugin') || msg.includes('扩展')) {
    return responses.plugin[Math.floor(Math.random() * responses.plugin.length)];
  }

  if (msg.includes('api') || msg.includes('接口') || msg.includes('rest')) {
    return responses.api[Math.floor(Math.random() * responses.api.length)];
  }

  if (msg.includes('配置') || msg.includes('config') || msg.includes('info.plug')) {
    return responses.config[Math.floor(Math.random() * responses.config.length)];
  }

  if (msg.includes('关于') || msg.includes('about') || msg.includes('介绍')) {
    return responses.about[Math.floor(Math.random() * responses.about.length)];
  }

  return [
    '我不太明白您的问题，可以换一种方式提问吗？',
    '抱歉，我暂时无法回答这个问题。',
    '您可以问我关于 RuntimeBay 的相关问题。',
    '请问您需要哪方面的帮助？'
  ][Math.floor(Math.random() * 4)];
}

function loadPort() {
  const infoPath = path.join(__dirname, 'info.plug');
  let port = 3005;
  try {
    const text = fs.readFileSync(infoPath, 'utf8');
    text.split('\n').forEach((line) => {
      const t = line.trim();
      if (t.toLowerCase().startsWith('port:')) {
        const n = parseInt(t.split(':')[1], 10);
        if (!Number.isNaN(n) && n > 0) port = n;
      }
    });
  } catch (_) {}
  return port;
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

function safeFilePath(root, rel) {
  const decoded = decodeURIComponent((rel || '').split('?')[0]);
  const normalized = path.normalize(decoded).replace(/^(\.\.(\/|\\|$))+/, '');
  const base = path.resolve(root);
  const target = path.resolve(base, normalized);
  const baseWithSep = base.endsWith(path.sep) ? base : base + path.sep;
  if (target !== base && !target.startsWith(baseWithSep)) return null;
  if (target === base) return null;
  return target;
}

function resolvePublicPath(pathname) {
  let rel = pathname.replace(/^\/+/, '') || '';

  if (rel === '' || rel.endsWith('/')) {
    const indexPath = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexPath && fs.existsSync(indexPath)) return indexPath;
  }

  let filePath = safeFilePath(PUBLIC_ROOT, rel);
  if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return filePath;
  }

  if (rel && !path.extname(rel)) {
    const asHtml = safeFilePath(PUBLIC_ROOT, rel + '.html');
    if (asHtml && fs.existsSync(asHtml) && fs.statSync(asHtml).isFile()) return asHtml;
    const indexInDir = safeFilePath(PUBLIC_ROOT, path.join(rel, 'index.html'));
    if (indexInDir && fs.existsSync(indexInDir) && fs.statSync(indexInDir).isFile()) {
      return indexInDir;
    }
  }

  return null;
}

function sendFile(req, res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }
    const type = contentType(filePath);
    const headers = {
      'Content-Type': type,
      'Cache-Control': 'public, max-age=3600',
    };
    if (req.method === 'HEAD') {
      res.writeHead(200, { ...headers, 'Content-Length': st.size });
      res.end();
      return;
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    fs.createReadStream(filePath).pipe(res);
  });
}

function parseBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      const parsed = JSON.parse(body);
      callback(null, parsed);
    } catch (err) {
      try {
        const params = new URLSearchParams(body);
        const obj = {};
        params.forEach((value, key) => {
          obj[key] = value;
        });
        callback(null, obj);
      } catch (e) {
        callback(e, null);
      }
    }
  });
}

const PORT = loadPort();

http
  .createServer((req, res) => {
    const pathname = path.posix.normalize((url.parse(req.url).pathname || '/').replace(/\\/g, '/'));
    const query = url.parse(req.url, true).query;

    if (pathname.startsWith('..')) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    if (pathname === '/api/chat') {
      if (req.method === 'GET') {
        const message = query.message || '';
        const response = getResponse(message);
        
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({
          success: true,
          message: response,
          timestamp: Date.now()
        }));
        return;
      }

      if (req.method === 'POST') {
        parseBody(req, (err, body) => {
          if (err) {
            res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ success: false, message: 'Invalid request body' }));
            return;
          }

          const message = body.message || '';
          const response = getResponse(message);

          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({
            success: true,
            message: response,
            timestamp: Date.now()
          }));
        });
        return;
      }

      res.writeHead(405, { Allow: 'GET, POST', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    if (pathname === '/api/health') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ success: true, status: 'online', timestamp: Date.now() }));
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
      return;
    }

    let filePath = resolvePublicPath(pathname);

    if (!filePath) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }

    sendFile(req, res, filePath);
  })
  .listen(PORT, () => {
    console.log(`[ChatBot] Public: ${PUBLIC_ROOT}`);
    console.log(`[ChatBot] 端口 ${PORT}（/ → Public；/api/chat 聊天接口）`);
  });
